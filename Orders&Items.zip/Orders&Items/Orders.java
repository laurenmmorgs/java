import java.util.ArrayList;

public class Orders {
   public String name;
   public Double total;
   public Boolean ready;
   public ArrayList<String> items = new ArrayList<String>();
}

public class Items {
   public Double price;
   public String name;
}
